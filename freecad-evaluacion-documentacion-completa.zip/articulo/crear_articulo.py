from pathlib import Path
import json

from docx import Document
from docx.shared import Cm, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn


ROOT = Path(__file__).resolve().parent
TITLE = 'Evaluación preliminar de Qwen3.5-9B para el modelado en FreeCAD'
BLOCKS = [
    ('declaration', 'Avance de una investigación en curso.'),
    ('heading', 'Resumen'),
    ('text', 'Se presenta un estudio piloto del modelo de pesos abiertos Qwen3.5-9B para ejecutar tareas de modelado mediante herramientas de FreeCAD. Se examinaron cuatro casos; las formas obtenidas en tres de ellos se contrastaron con referencias geométricas independientes. Se identificaron resultados geométricamente correctos, dependencias rotas, un bolsillo desplazado y una ejecución incompleta. Los hallazgos aportan criterios para evaluar geometría, estructura del documento y registros de ejecución.'),
    ('heading', 'Introducción'),
    ('text', 'FreeCAD permite modificar diseños mediante parámetros y relaciones entre operaciones [1]. Model Context Protocol (MCP) ofrece una arquitectura para conectar aplicaciones de inteligencia artificial con herramientas externas [2]. Esta integración plantea una pregunta práctica: ¿las operaciones realizadas por un modelo de lenguaje satisfacen las restricciones del diseño? El objetivo del estudio es establecer criterios verificables para evaluar esa correspondencia en un entorno local.'),
    ('heading', 'Metodología'),
    ('text', 'Se empleó Qwen3.5-9B en formato GGUF Q4_K_M [3], con LM Studio 0.4.26+4, un servidor MCP para FreeCAD y FreeCAD 1.1.1. El archivo del modelo ocupa 5,63 GB. La estación utilizó una GPU NVIDIA RTX A6000 de 48 GB. Los prompts en inglés especificaron dimensiones, posiciones y operaciones booleanas.'),
    ('text', 'Se conservaron conversaciones y documentos FCStd. La revisión posterior en FreeCAD comprobó validez de la forma, número de sólidos y enlaces entre objetos. Para comparar una pieza S con una referencia R construida aparte se calcularon los volúmenes de S menos R y de R menos S, con una tolerancia de 10⁻⁶ mm³ en cada diferencia. Los resúmenes del modelo se contrastaron con estas mediciones. Se describen casos de un proceso iterativo con reintentos, sin calcular una tasa de éxito.'),
    ('heading', 'Resultados y discusión'),
    ('text', 'La Tabla 1 resume los casos examinados.'),
    ('caption', 'Tabla 1. Resultados preliminares por caso'),
    ('table', [
        ['Caso', 'Tarea', 'Resultado'],
        ['T1', '40 × 30 × 10 mm; agujero Ø8\u00a0mm', 'Geometría correcta; corte inválido'],
        ['T2', '60 × 40 × 8 mm; cuatro agujeros Ø5\u00a0mm', 'Coincidencia geométrica verificada'],
        ['T3', '60 × 40 × 10 mm; bolsillo ciego', 'Posición incorrecta'],
        ['T4', '80 × 50 × 8 mm; agujeros y bolsillo', 'Ejecución incompleta'],
    ]),
    ('text', 'En T1, la geometría coincidió con la referencia, pero el corte quedó inválido al eliminarse sus objetos base y herramienta. En T2, la pieza fue válida, con un sólido y diferencias volumétricas nulas; conservó los cortes, aunque la placa base era una forma sin dimensiones paramétricas editables.'),
    ('text', 'T3 produjo un bolsillo de 20 × 12 × 4 mm desplazado 10 mm en X y 6 mm en Y. El volumen total fue el esperado, 23 040 mm³, pero ambas diferencias booleanas alcanzaron 720 mm³. Este caso muestra que verificar únicamente el volumen puede aceptar una pieza mal posicionada.'),
    ('text', 'T4, registrada con Think activado, no produjo un resultado final verificable. El cronometraje manual abarcó 26 min 41 s, incluidos reintentos y esperas. El registro contuvo 131 llamadas, incluidas nueve con tiempo de espera agotado. En las muestras tomadas aproximadamente cada dos segundos, el proceso de inferencia ocupó 7484 MiB de VRAM y alcanzó 11 141 MiB de memoria residente. El archivo parcial conservó 51 objetos; la causa del bloqueo no pudo determinarse.'),
    ('heading', 'Limitaciones y conclusiones'),
    ('text', 'El estudio abarca un modelo, casos exploratorios y reintentos con registro incompleto de parámetros de generación. La comparación con Think desactivado sigue pendiente. Por ello, los resultados no permiten estimar fiabilidad general ni atribuir diferencias al razonamiento activado.'),
    ('text', 'El aporte del avance es un procedimiento de evaluación que distingue geometría válida, cumplimiento de restricciones y conservación de dependencias. Las próximas ejecuciones deberán fijar parámetros, repetir cada condición y mantener la verificación independiente antes de incorporar las piezas a un flujo de diseño.'),
    ('heading', 'Referencias bibliográficas'),
    ('reference', '[1] FreeCAD Project. FreeCAD. https://github.com/FreeCAD/FreeCAD'),
    ('reference', '[2] Model Context Protocol. Architecture overview. https://modelcontextprotocol.io/docs/learn/architecture'),
    ('reference', '[3] LM Studio Community. Qwen3.5-9B-GGUF. https://huggingface.co/lmstudio-community/Qwen3.5-9B-GGUF'),
]


def set_font(style):
    style.font.name = 'Times New Roman'
    style.font.size = Pt(12)
    style.font.color.rgb = RGBColor(0, 0, 0)
    fonts = style.element.get_or_add_rPr().get_or_add_rFonts()
    for key in list(fonts.attrib):
        if 'theme' in key.lower():
            del fonts.attrib[key]
    for name in ('ascii', 'hAnsi', 'eastAsia', 'cs'):
        fonts.set(qn('w:' + name), 'Times New Roman')
    if hasattr(style, 'paragraph_format'):
        pf = style.paragraph_format
        pf.line_spacing = 2
        pf.space_before = Pt(0)
        pf.space_after = Pt(0)
        pf.widow_control = True
    for border in list(style.element.findall('.//' + qn('w:pBdr'))):
        border.getparent().remove(border)
    rpr = style.element.get_or_add_rPr()
    szcs = rpr.find(qn('w:szCs'))
    if szcs is not None:
        szcs.set(qn('w:val'), '24')


def create_docx():
    doc = Document()
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Cm(21), Cm(29.7)
    sec.left_margin, sec.right_margin = Cm(3), Cm(2.5)
    sec.top_margin = sec.bottom_margin = Cm(2.5)
    sec.footer_distance = Cm(1.25)
    for name in ('Normal', 'Title', 'Heading 1', 'Caption', 'Title Char', 'Heading 1 Char'):
        set_font(doc.styles[name])
    doc.styles['Normal'].paragraph_format.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    for name in ('Title', 'Heading 1'):
        doc.styles[name].font.bold = True
    doc.styles['Title'].paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
    doc.styles['Heading 1'].paragraph_format.keep_with_next = True
    doc.styles['Caption'].font.italic = False
    doc.core_properties.title = TITLE
    doc.core_properties.subject = 'Estudio piloto de automatización de FreeCAD mediante Qwen y MCP'
    doc.core_properties.author = ''
    doc.core_properties.keywords = 'FreeCAD, Qwen, MCP, evaluación geométrica'

    doc.add_paragraph(TITLE, 'Title')
    # Blank space reserved for author, affiliation and email, as requested.
    doc.add_paragraph('')
    doc.add_paragraph('')
    after_table = False
    for kind, content in BLOCKS:
        if kind == 'heading':
            doc.add_paragraph(content, 'Heading 1')
        elif kind == 'table':
            table = doc.add_table(rows=0, cols=3)
            table.alignment = WD_TABLE_ALIGNMENT.CENTER
            table.autofit = False
            widths = (1.2, 7.0, 7.3)
            for i, w in enumerate(widths):
                table.columns[i].width = Cm(w)
            for row_index, values in enumerate(content):
                row = table.add_row()
                trpr = row._tr.get_or_add_trPr()
                trpr.append(OxmlElement('w:cantSplit'))
                if row_index == 0:
                    repeat = OxmlElement('w:tblHeader')
                    trpr.append(repeat)
                for i, value in enumerate(values):
                    cell = row.cells[i]
                    cell.width = Cm(widths[i])
                    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
                    p = cell.paragraphs[0]
                    p.alignment = WD_ALIGN_PARAGRAPH.CENTER if i == 0 else WD_ALIGN_PARAGRAPH.LEFT
                    p.add_run(value).bold = row_index == 0
                    tcpr = cell._tc.get_or_add_tcPr()
                    borders = OxmlElement('w:tcBorders')
                    for side in ('top', 'left', 'bottom', 'right'):
                        e = OxmlElement('w:' + side)
                        e.set(qn('w:val'), 'single')
                        e.set(qn('w:sz'), '4')
                        e.set(qn('w:color'), 'D9D9D9')
                        borders.append(e)
                    tcpr.append(borders)
                    margins = OxmlElement('w:tcMar')
                    for side in ('top', 'bottom', 'left', 'right'):
                        e = OxmlElement('w:' + side)
                        e.set(qn('w:w'), '70')
                        e.set(qn('w:type'), 'dxa')
                        margins.append(e)
                    tcpr.append(margins)
                    if row_index == 0:
                        shade = OxmlElement('w:shd')
                        shade.set(qn('w:fill'), 'EDEDED')
                        tcpr.append(shade)
            after_table = True
        else:
            p = doc.add_paragraph(content, 'Caption' if kind == 'caption' else 'Normal')
            if kind in ('text', 'reference'):
                p.paragraph_format.keep_together = True
            if after_table:
                p.paragraph_format.space_before = Pt(6)
                after_table = False
            if kind == 'caption':
                p.paragraph_format.keep_with_next = True
                p.alignment = WD_ALIGN_PARAGRAPH.LEFT
            if kind == 'reference':
                p.alignment = WD_ALIGN_PARAGRAPH.LEFT
    footer = sec.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    field = OxmlElement('w:fldSimple')
    field.set(qn('w:instr'), 'PAGE')
    run = OxmlElement('w:r')
    text = OxmlElement('w:t')
    text.text = '1'
    run.append(text)
    field.append(run)
    footer._p.append(field)
    out = ROOT / 'Articulo_FreeCAD_Qwen.docx'
    doc.save(out)
    return out


def create_markdown():
    parts = ['# ' + TITLE, '', '<!-- Datos de autor, afiliación y correo reservados en el Word. -->', '']
    for kind, content in BLOCKS:
        if kind == 'heading':
            parts.append('## ' + content)
        elif kind == 'table':
            parts.append('| ' + ' | '.join(content[0]) + ' |')
            parts.append('| --- | --- | --- |')
            parts.extend('| ' + ' | '.join(row) + ' |' for row in content[1:])
        else:
            parts.append(content)
        parts.append('')
    (ROOT / 'Articulo_FreeCAD_Qwen.md').write_text('\n'.join(parts), encoding='utf-8')


if __name__ == '__main__':
    output = create_docx()
    create_markdown()
    words = len((TITLE + ' ' + ' '.join(c if isinstance(c, str) else ' '.join(' '.join(r) for r in c) for _, c in BLOCKS)).split())
    print(output)
    print('Words:', words)
