# Evaluación preliminar de Qwen3.5-9B para el modelado en FreeCAD

<!-- Datos de autor, afiliación y correo reservados en el Word. -->

Avance de una investigación en curso.

## Resumen

Se presenta un estudio piloto del modelo de pesos abiertos Qwen3.5-9B para ejecutar tareas de modelado mediante herramientas de FreeCAD. Se examinaron cuatro casos; las formas obtenidas en tres de ellos se contrastaron con referencias geométricas independientes. Se identificaron resultados geométricamente correctos, dependencias rotas, un bolsillo desplazado y una ejecución incompleta. Los hallazgos aportan criterios para evaluar geometría, estructura del documento y registros de ejecución.

## Introducción

FreeCAD permite modificar diseños mediante parámetros y relaciones entre operaciones [1]. Model Context Protocol (MCP) ofrece una arquitectura para conectar aplicaciones de inteligencia artificial con herramientas externas [2]. Esta integración plantea una pregunta práctica: ¿las operaciones realizadas por un modelo de lenguaje satisfacen las restricciones del diseño? El objetivo del estudio es establecer criterios verificables para evaluar esa correspondencia en un entorno local.

## Metodología

Se empleó Qwen3.5-9B en formato GGUF Q4_K_M [3], con LM Studio 0.4.26+4, un servidor MCP para FreeCAD y FreeCAD 1.1.1. El archivo del modelo ocupa 5,63 GB. La estación utilizó una GPU NVIDIA RTX A6000 de 48 GB. Los prompts en inglés especificaron dimensiones, posiciones y operaciones booleanas.

Se conservaron conversaciones y documentos FCStd. La revisión posterior en FreeCAD comprobó validez de la forma, número de sólidos y enlaces entre objetos. Para comparar una pieza S con una referencia R construida aparte se calcularon los volúmenes de S menos R y de R menos S, con una tolerancia de 10⁻⁶ mm³ en cada diferencia. Los resúmenes del modelo se contrastaron con estas mediciones. Se describen casos de un proceso iterativo con reintentos, sin calcular una tasa de éxito.

## Resultados y discusión

La Tabla 1 resume los casos examinados.

Tabla 1. Resultados preliminares por caso

| Caso | Tarea | Resultado |
| --- | --- | --- |
| T1 | 40 × 30 × 10 mm; agujero Ø8 mm | Geometría correcta; corte inválido |
| T2 | 60 × 40 × 8 mm; cuatro agujeros Ø5 mm | Coincidencia geométrica verificada |
| T3 | 60 × 40 × 10 mm; bolsillo ciego | Posición incorrecta |
| T4 | 80 × 50 × 8 mm; agujeros y bolsillo | Ejecución incompleta |

En T1, la geometría coincidió con la referencia, pero el corte quedó inválido al eliminarse sus objetos base y herramienta. En T2, la pieza fue válida, con un sólido y diferencias volumétricas nulas; conservó los cortes, aunque la placa base era una forma sin dimensiones paramétricas editables.

T3 produjo un bolsillo de 20 × 12 × 4 mm desplazado 10 mm en X y 6 mm en Y. El volumen total fue el esperado, 23 040 mm³, pero ambas diferencias booleanas alcanzaron 720 mm³. Este caso muestra que verificar únicamente el volumen puede aceptar una pieza mal posicionada.

T4, registrada con Think activado, no produjo un resultado final verificable. El cronometraje manual abarcó 26 min 41 s, incluidos reintentos y esperas. El registro contuvo 131 llamadas, incluidas nueve con tiempo de espera agotado. En las muestras tomadas aproximadamente cada dos segundos, el proceso de inferencia ocupó 7484 MiB de VRAM y alcanzó 11 141 MiB de memoria residente. El archivo parcial conservó 51 objetos; la causa del bloqueo no pudo determinarse.

## Limitaciones y conclusiones

El estudio abarca un modelo, casos exploratorios y reintentos con registro incompleto de parámetros de generación. La comparación con Think desactivado sigue pendiente. Por ello, los resultados no permiten estimar fiabilidad general ni atribuir diferencias al razonamiento activado.

El aporte del avance es un procedimiento de evaluación que distingue geometría válida, cumplimiento de restricciones y conservación de dependencias. Las próximas ejecuciones deberán fijar parámetros, repetir cada condición y mantener la verificación independiente antes de incorporar las piezas a un flujo de diseño.

## Referencias bibliográficas

[1] FreeCAD Project. FreeCAD. https://github.com/FreeCAD/FreeCAD

[2] Model Context Protocol. Architecture overview. https://modelcontextprotocol.io/docs/learn/architecture

[3] LM Studio Community. Qwen3.5-9B-GGUF. https://huggingface.co/lmstudio-community/Qwen3.5-9B-GGUF
